/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas220525;

/**
 *
 * @author USER
 */
class TransferBank extends Pembayaran implements MetodePembayaran {
    private String namaBank;

    public TransferBank(double totalBayar, String namaBank) {
        super(totalBayar);
        this.namaBank = namaBank;
    }

    
    @Override
    public void prosesPembayaran() {
        System.out.println("Memproses pembayaran via transfer bank...");
        System.out.println("Total: Rp" + totalBayar);
        System.out.println("Bank Tujuan: " + namaBank);
        System.out.println("Pembayaran berhasil diproses!");
    }

    
    @Override
    public void tampilkanDetail() {
        System.out.println("Metode: Transfer Bank");
        System.out.println("Bank: " + namaBank);
    }
}
