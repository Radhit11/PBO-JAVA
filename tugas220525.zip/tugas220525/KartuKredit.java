/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas220525;

/**
 *
 * @author USER
 */
class KartuKredit extends Pembayaran implements MetodePembayaran {
    private String bank;
    private String nomorKartu;

    public KartuKredit(double totalBayar, String bank, String nomorKartu) {
        super(totalBayar);
        this.bank = bank;
        this.nomorKartu = nomorKartu;
    }

    
    @Override
    public void prosesPembayaran() {
        System.out.println("Memproses pembayaran via Kartu Kredit...");
        System.out.println("Total: Rp" + totalBayar);
        System.out.println("Bank: " + bank);
        System.out.println("4 digit terakhir: " + nomorKartu.substring(nomorKartu.length() - 4));
        System.out.println("Pembayaran berhasil diproses!");
    }

    
    @Override
    public void tampilkanDetail() {
        System.out.println("Metode: Kartu Kredit");
        System.out.println("Bank: " + bank);
    }
}
